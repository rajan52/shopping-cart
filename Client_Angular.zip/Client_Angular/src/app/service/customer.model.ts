export class Customer
{
    id: number;
    name: string;
    userName: string;
    password: string;
    totalPrce: number;
    discountedPrice:number;
    discountPercentage:number;
    type:string;
}